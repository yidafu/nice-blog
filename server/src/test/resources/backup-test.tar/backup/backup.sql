-- Generate backup sql at 2025-04-04 21:17

-- generate ddl begin
create table if not exists B_ACCESS_LOG (ID integer primary key autoincrement not null, ACCESS_TIME datetime(6) default (CURRENT_TIMESTAMP), IP varchar(64), REFERRER_URL varchar(512), SOURCE_URL varchar(512) not null, UA varchar(64), UID varchar(16) not null);
create table if not exists B_ARTICLE (ID integer primary key autoincrement not null, CREATED_AT datetime(6) default (CURRENT_TIMESTAMP), UPDATED_AT datetime(6) default (CURRENT_TIMESTAMP), CONTENT varchar(1000000000), COVER varchar(255), HASH varchar(255), HTML varchar(1000000000), IDENTIFIER varchar(255), SERIES varchar(255), SOURCE_TYPE varchar(255), STATUS int, SUMMARY varchar(255), TITLE varchar(255));
create table if not exists B_ARTICLE_HISTORY (ID integer primary key autoincrement not null, CREATED_AT datetime(6) default (CURRENT_TIMESTAMP), UPDATED_AT datetime(6) default (CURRENT_TIMESTAMP), ARTICLE_ID int8, RAW_CONTENT varchar(255), RENDERED_CONTENT varchar(255));
create table if not exists B_CONFIGURATION (ID integer primary key autoincrement not null, CREATED_AT datetime(6) default (CURRENT_TIMESTAMP), UPDATED_AT datetime(6) default (CURRENT_TIMESTAMP), CONFIG_KEY varchar(255), CONFIG_VALUE varchar(255), constraint UKR9EYOBGIOQOJSDRAYEEYMUNJH unique (CONFIG_KEY));
create table if not exists B_SYNC_TASK (ID integer primary key autoincrement not null, CREATED_AT datetime(6) default (CURRENT_TIMESTAMP), UPDATED_AT datetime(6) default (CURRENT_TIMESTAMP), CALLBACK_URL varchar(255), LOGS varchar(1000000000) default (''), STATUS int, UUID varchar(255));
create table if not exists B_USER (ID integer primary key autoincrement not null, CREATED_AT datetime(6) default (CURRENT_TIMESTAMP), UPDATED_AT datetime(6) default (CURRENT_TIMESTAMP), EMAIL varchar(255), LOGIN_COUNT varchar(255), PASSWORD varchar(255), STATUS int, USERNAME varchar(255), constraint UK_9X6TW7BOCI1EVWR46R5OMOUKA unique (USERNAME));
create table if not exists B_USER_TOKEN (ID integer primary key autoincrement not null, CREATED_AT datetime(6) default (CURRENT_TIMESTAMP), UPDATED_AT datetime(6) default (CURRENT_TIMESTAMP), CREATED_BY varchar(255) not null, DESCRIPTION varchar(255), EXPIRES_AT datetime(6) not null, NAME varchar(255), TOKEN varchar(32) not null, constraint UK_1D63EUQ1SRIUU4GWDPQHR6559 unique (TOKEN));
-- generate ddl end

-------------------------------- Table(B_CONFIGURATION) Data --------------------------------
insert into B_CONFIGURATION (ID, CREATED_AT, UPDATED_AT, CONFIG_KEY, CONFIG_VALUE) values (1, '2025-04-04 07:41:51.0', '2025-04-04 07:41:51.0', 'appearance.site_title', 'Dov Yih')
insert into B_CONFIGURATION (ID, CREATED_AT, UPDATED_AT, CONFIG_KEY, CONFIG_VALUE) values (2, '2025-04-04 07:41:51.0', '2025-04-04 07:41:51.0', 'appearance.github_url', 'https://github.com/yidafu')
insert into B_CONFIGURATION (ID, CREATED_AT, UPDATED_AT, CONFIG_KEY, CONFIG_VALUE) values (3, '2025-04-04 07:41:51.0', '2025-04-04 07:41:51.0', 'synchronous.cron_expr', '0 0/1 * * * ?')
insert into B_CONFIGURATION (ID, CREATED_AT, UPDATED_AT, CONFIG_KEY, CONFIG_VALUE) values (4, '2025-04-04 07:41:51.0', '2025-04-04 07:41:51.0', 'data_source.type', 'git')
insert into B_CONFIGURATION (ID, CREATED_AT, UPDATED_AT, CONFIG_KEY, CONFIG_VALUE) values (5, '2025-04-04 07:41:51.0', '2025-04-04 07:41:51.0', 'data_source.url', 'https://github.com/yidafu/example-blog.git')
insert into B_CONFIGURATION (ID, CREATED_AT, UPDATED_AT, CONFIG_KEY, CONFIG_VALUE) values (6, '2025-04-04 07:41:51.0', '2025-04-04 07:41:51.0', 'data_source.token', '')
insert into B_CONFIGURATION (ID, CREATED_AT, UPDATED_AT, CONFIG_KEY, CONFIG_VALUE) values (7, '2025-04-04 07:41:51.0', '2025-04-04 07:41:51.0', 'data_source.branch', '')
insert into B_CONFIGURATION (ID, CREATED_AT, UPDATED_AT, CONFIG_KEY, CONFIG_VALUE) values (8, '2025-04-04 07:42:51.0', '2025-04-04 07:42:51.0', 'backup.root_dir', './backup')
-------------------------------- Table(B_CONFIGURATION) Data --------------------------------

-------------------------------- Table(B_USER) Data --------------------------------
insert into B_USER (ID, CREATED_AT, UPDATED_AT, EMAIL, LOGIN_COUNT, PASSWORD, STATUS, USERNAME) values (1, '2025-04-04 07:41:51.0', '2025-04-04 07:41:51.0', '', null, 'AZICOnu9cyUFFvBp3xi1AA==', 1, 'admin')
-------------------------------- Table(B_USER) Data --------------------------------